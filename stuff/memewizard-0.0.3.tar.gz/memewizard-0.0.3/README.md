# memecli
Retrieve meme information from the terminal
![img](https://github.com/ajskateboarder/stuff/blob/main/terminal.png?raw=true)

# To-do
- Rewrite this in Javascript since this is horrendously slow
