# memewizard
Retrieve meme information from the terminal

<img src="https://github.com/ajskateboarder/stuff/blob/main/terminal.png?raw=true" height=600>

## Requirements
Python 3.9. That's it.


## Installation
### Windows 10 or higher

Copy this one liner into Powershell

``` powershell
cmd /c $(Invoke-WebRequest "https://raw.githubusercontent.com/ajskateboarder/stuff/main/more/install.bat")
```
<sub>why do i feel so proud of this code</sub>

This downloads a script which automates the process. This will also add memewizard to your PATH, meaning you can be in any directory when using this.
