# memewizard
Retrieve meme information from the terminal

![img](https://github.com/ajskateboarder/stuff/blob/main/terminal.png?raw=true)
